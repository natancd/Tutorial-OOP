﻿/** NumericFormatting
 *	
 *	An example of formatting numeric results in C#
 *   
 *	author		T. MacDonald
 *	since		2 Jan 2016
 *  see		    MSDN: Formatting Numeric Results (https://msdn.microsoft.com/en-us/library/s8s7t687%28v=vs.110%29.aspx)
 *  
 * You can format numeric results by using the String.Format method, or through the Console.Write or Console.WriteLine method, 
 * which calls String.Format. The format is specified by using format strings. The following table contains the supported 
 * standard format strings. The format string takes the following form: Axx, where A is the format specifier and xx is the 
 * precision specifier. The format specifier controls the type of formatting applied to the numeric value, and the precision 
 * specifier controls the number of significant digits or decimal places of the formatted output. The value of the precision 
 * specifier ranges from 0 to 99.
 * 
 * For more information about standard and custom formatting strings, see Formatting Types. For more information about the 
 * String.Format method, see String.Format.
 * 
 * Character   Description Examples                            Output
 * C or c 	    Currency 	Console.Write("{0:C}", 2.5);        $2.50
 *                          Console.Write("{0:C}", -2.5);       ($2.50)
 *  D or d 	    Decimal     Console.Write("{0:D5}", 25);        00025
 *  E or e 	    Scientific 	Console.Write("{0:E}", 250000);     2.500000E+005
 *  F or f 	    Fixed-point Console.Write("{0:F2}", 25);        25.00
 *                          Console.Write("{0:F0}", 25);        25
 *  G or g 	    General 	Console.Write("{0:G}", 2.5); 	    2.5
 *  N or n 	    Number 	    Console.Write("{0:N}", 2500000); 	2,500,000.00
 *  X or x 	   Hexadecimal 	Console.Write("{0:X}", 250);        FA
 *                          Console.Write("{0:X}", 0xffff);     FFFF
*/

using System;
namespace NumericFormatting
{
    class Program
    {
       
        static void Main(string[] args)
        {
            double[] numbers = { 55.5, 22.0, 9111.4, 1.11111, -6.0 }; // a list of sample numbers

            Console.WriteLine("\nNumbers unformatted:");
            foreach (double num in numbers)
            {
                Console.WriteLine("{0}", num); // number, as it is
            }
            Console.WriteLine("\nContinue...");
            Console.ReadKey();

            Console.WriteLine("\nNumbers: Fixed, 2 decimal places:");
            foreach (double num in numbers)
            {
                Console.WriteLine("{0:F2}", num); // number in Fixed Point format with 2 decimal places
            }
            Console.WriteLine("\nContinue...");
            Console.ReadKey();

            Console.WriteLine("\nNumbers: right aligned in a field of 10:");
            foreach (double num in numbers)
            {
                Console.WriteLine("{0}", num.ToString().PadLeft(10)); // number as it is, in a field
            }
            Console.WriteLine("\nContinue...");
            Console.ReadKey();

            Console.WriteLine("\nNumbers: Numeric, 2 decimal places, right aligned in a field of 10:");
            foreach (double num in numbers)
            {
                Console.WriteLine("{0}", String.Format("{0:N2}", num).PadLeft(10)); // formatting and field width together
            }
            Console.WriteLine();
            Console.ReadKey();
      
        }
    }
}
