﻿/*  NestedLoops
 * 
 *  This is a solution to a lab from a previous course. It demonstrates a basic C# program with console 
 *	input and output and nested loops.
 * 
 *  author      Thom MacDonald
 *  since       2 Jan 2016
 *  
 * REQUIREMENTS
 * ============
 * 
 * A scientific researcher is performing a series of four experiments and each experiment has at least two, 
 * but not more than six test results.  The researcher needs to know the average test result for each 
 * experiment as well as the overall average of all experiments.  In this lab we will create a console C# 
 * program that will allow the researcher to enter the test results and display the required averages.
 *  
 * Getting User Input
 * A suitable input loop structure to handle the fact that each experiment has a different number of results.  
 * There are a number of ways to go about this. Whichever technique we use to structure the input loop should
 * be reasonably smooth for the user. For example, asking the user to enter “Y” or “N” if they want to add 
 * another test result after every single entry might be too awkward an approach.  
 * •	All four experiments have between two and six test results.  
 * •	The actual test results are extremely precise numbers between -1.0 and +1.0.  Input validation is required.
 * 
 * Displaying the Required Output
 * We will not round the average test results.  It is acceptable to calculate and display the average test 
 * result for an experiment immediately after the user enters the results for that experiment rather than wait 
 * until all the experiments have been entered.
 * 
 * Other Notes
 * •	There is no explicit requirement to use an array or any other collection data structure.
 * •	There is also no explicit requirement to write any methods other than Main( ).
 *      
 */

using System;

namespace NestedLoops
{
    class Program
    {
        static void Main(string[] args)
        {
                    // DECLARATIONS
            const int NUMBER_OF_EXPERIMENTS = 4;    // The total number of experiments conducted
            const int MIN_TESTS_PER_EXP = 2;        // The minimum number of test results per experiment
            const int MAX_TESTS_PER_EXP = 6;        // The maximum number of test results per experiment
            const decimal MIN_TEST_RESULT = -1.0m;  // The minimum test result value
            const decimal MAX_TEST_RESULT = 1.0m;   // the maximum test result value

            string input;                           // a temporary string used to get input from the user
            bool needInput;                         // a flag used for input validation 
            int numberOfTests;                      // the number of tests for the current experiment
            int totalNumberOfTests = 0;             // the total number of tests conducted for all experiments
            decimal testResult;                     // the result of the current test
            decimal sumExperimentResults = 0.0m;    // the sum of all the results for the current experiment
            decimal sumTotalResults = 0.0m;         // the sum of all the results for all experiments

            // START           
            // for each experiment
            for (int experiment = 1; experiment <= NUMBER_OF_EXPERIMENTS; experiment++)
            {

                // Determine how many tests for this experiment
                needInput = true;
                do // validation loop for number of tests input
                {
                    sumExperimentResults = 0.0m; // reset the sum of all results for this experiment
                    Console.Write("How many tests were conducted in experiment #{0}? ", experiment); // prompt for the current number of tests
                    input = Console.ReadLine();
                    if (int.TryParse(input, out numberOfTests)) // try to convert the input into an integer
                    {
                        if (numberOfTests >= MIN_TESTS_PER_EXP && numberOfTests <= MAX_TESTS_PER_EXP) // if the number of tests is within the valid range
                        {
                            needInput = false; // we have the input we need. Stop the validation loop.
                        }
                        else // input is an integer, but outside the valid range.
                        {
                            // report error
                            Console.WriteLine("Each experiment has a minimium of {0} and a maximium of {1} test results.\nPlease try again.\n", MIN_TESTS_PER_EXP, MAX_TESTS_PER_EXP);
                        }
                    }
                    else // input is not an integer
                    {
                        // report error
                        Console.WriteLine("Please enter a whole number.\n");
                    }

                } while (needInput); // continue until we have a valid number of tests

                // for each test of the current experiment
                for (int test = 1; test <= numberOfTests; ) // note, does not increment counter by default
                {
                    // prompt for the current test result    
                    Console.Write("Please enter the result for experiment #{0}, test #{1}: ", experiment, test);
                    input = Console.ReadLine();
                    if (decimal.TryParse(input, out testResult)) // try to convert the input into a decimal
                    {
                        if (testResult >= MIN_TEST_RESULT && testResult <= MAX_TEST_RESULT) // if the test result is in the valid range
                        {
                            // add the current test result to the sum of experiment test results
                            sumExperimentResults += testResult;
                            // increment the test counter, i.e. next test result.
                            test++;
                        }
                        else // test result was numeric, but outside the valid range
                        {
                            Console.WriteLine("The test result must be between {0:n1} and {1:n1}.\nPlease try again.\n", MIN_TEST_RESULT, MAX_TEST_RESULT);
                        }
                    }
                    else // test result was not numeric
                    {
                        Console.WriteLine("Please enter a numeric value.\n");
                    }

                } // end of input for the current experiment

                // add the sum of experiment results to the total results sum
                sumTotalResults += sumExperimentResults;
                // add the number of tests for this experiment to the total number of tests
                totalNumberOfTests += numberOfTests;

                // calculate and display the current experiment average
                Console.WriteLine("\nThe average for experiment #{0} is {1}", experiment, sumExperimentResults / numberOfTests);

                // pause and clear the console
                Console.Write("Press any key to continue...");
                Console.ReadKey();
                Console.Clear();

            } // end of input for all experiments

            // calculate and display the average of all experiments
            Console.WriteLine("\nThe overall average for {0} experiments is {1}", NUMBER_OF_EXPERIMENTS, sumTotalResults / totalNumberOfTests);

            // Pause before exit
            Console.Write("Press any key to exit...");

            Console.ReadKey();
        }
    }
}
