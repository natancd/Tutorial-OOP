﻿/** NumericInput
 *	
 *	Three examples of capturing numeric input in C#.
 *   
 *	author		T. MacDonald
 *	since		2 Jan 2016
 *	see         MSDN - How to: Convert a String to a Number (https://msdn.microsoft.com/en-CA/library/bb397679%28v=vs.110%29.aspx)
*/

using System;

namespace NumericInput
{
    class Program
    {
        static void Main(string[] args)
        {

            /****************
             * DECLARATIONS *
             ****************/
            
            string userInput = "";  // the sequence of characters the user input
            int numberStored;       // the converted numeric value.
            bool needInput = true;  // the control for the input loop(s)


            #region  Example # 1 - Convert Class or Parse Method
            
            /***********************************************
             * Example # 1 - Convert Class or Parse Method *
             ***********************************************/
            // Initial user prompt
            Console.WriteLine("Convert Class or Parse Method");
            Console.WriteLine("=============================\n");
            Console.Write("\nPlease enter a number and I will try to store it: ");
            
            do // start an input loop:
            {
                try // attempt IPO:
                {
                    // Store the user input as a string
                    userInput = Console.ReadLine();

                    // Convert the user input string to an int using Convert.ToInt32() or int.Parse()

                    //numberStored = Convert.ToInt32(userInput); // returns 0 if userInput is null (which is not possible in this example).
                    numberStored = int.Parse(userInput); // throws ArgumentNullException is userInput is null (which is not possible in this example).

                    // Success! 
                    needInput = false; // set the loop to end
                    Console.WriteLine("The number you entered was {0}.", numberStored); // display the output value
                }
                // Failure due to format problem:
                catch (FormatException e)
                {
                    // Show the type of exception, the user input and explain to the user what is wrong.
                    Console.WriteLine("{0} - \"{1}\" is not a valid sequence of characters.", e.GetType().ToString(), userInput);
                }
                // Failure due to overflow problem:
                catch (OverflowException e)
                {
                    // Show the type of exception, the user input and explain to the user what is wrong.
                    Console.WriteLine("{0} - \"{1}\" cannot fit into a 32-bit integer.", e.GetType().ToString(), userInput);
                }
                // Failure due to some other problem (rare)
                catch (Exception e)
                {
                    // Show the type of exception, the user input and explain to the user what is wrong.
                    Console.WriteLine("{0} - \"{1}\" caused an exception.", e.GetType().ToString(), userInput);
                }

                // If user input is still needed:
                if(needInput)
                {
                    // Prompt the user to try again
                    Console.Write("Please try again: ");
                }

            } while (needInput); // Continue looping until input is not needed.

            #endregion

            // Pause and clear the console for the next example.
            Console.WriteLine("\n\nPress any key to continue...");
            Console.ReadKey();
            Console.Clear();

            #region Example # 2 - TryParse Method
            /***********************************************
             * Example # 2 - TryParse Method *
             ***********************************************/
            // Reset needInput to true for the next input loop
            needInput = true;
            // Initial user prompt
            Console.WriteLine("TryParse Method");
            Console.WriteLine("===============\n");
            Console.Write("\nPlease enter a number and I will try to store it: ");

            do // start an input loop:
            {
                // Store the user input as a string
                userInput = Console.ReadLine();

                // If the user input string can be parsed into an int:
                if (int.TryParse(userInput, out numberStored))
                {
                    needInput = false; // set the loop to end
                    Console.WriteLine("The number you entered was {0}.", numberStored); // display the output value
                }
                else // Otherwise, user input could not be parsed:
                {
                    // Show the user input and explain to the user what is wrong.
                    Console.WriteLine("\"{0}\" could not be parsed into a 32-bit integer.", userInput);
                    // Prompt the user to try again.
                    Console.Write("Please try again: ");
                }


            } while (needInput);  // Continue looping until input is not needed.

            #endregion

            // Pause and clear the console for the next example.
            Console.WriteLine("\n\nPress any key to continue...");
            Console.ReadKey();
            Console.Clear();

            #region Example # 3 - Custom Input Method Example
            /***********************************************
             * Example # 3 - Custom Input Method Example   *
             ***********************************************/
            Console.WriteLine("Custom Input Method");
            Console.WriteLine("===================\n");
            Console.Write("\nPlease enter a number and I will try to store it: ");
            
            numberStored = GetValidInteger();
            Console.WriteLine("The number you entered was {0}.", numberStored); // display the output value

            #endregion

            // Pause before ending the program.
            Console.WriteLine("\n\nPress any key to end...");
            Console.ReadKey();

        }

        /// <summary>
        /// Gets a valid integer value from the console.
        /// </summary>
        /// <returns>An user inputted integer value.</returns>
        static int GetValidInteger()
        {
            string userInput;  // the sequence of characters the user input
            int numberReturned;       // the converted numeric value.
            
            // Store the user input as a string
            userInput = Console.ReadLine();

            // If the user input string can be parsed into an int:
            if (!int.TryParse(userInput, out numberReturned))
            {
                // Show the user input and explain to the user what is wrong.
                Console.WriteLine("\"{0}\" could not be parsed into a 32-bit integer.", userInput);
                // Prompt the user to try again.
                Console.Write("Please try again: ");
                // restart the method using recursion:
                numberReturned = GetValidInteger();
            }

            return numberReturned;

        }
    }
}
